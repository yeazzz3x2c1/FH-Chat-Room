﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server_Application
{
    internal class Client
    {
        public delegate void Connection_Handler(Client client);
        public event Connection_Handler On_Disconnected;
        Socket client;
        public Client(Socket client) {
            this.client = client;
            IPEndPoint ipendpoint = client.RemoteEndPoint as IPEndPoint;
            Console.WriteLine("收到了連線請求，IP:" + ipendpoint.Address + ":" + ipendpoint.Port);
            Listen();
        }
        private void Listen()
        {
            new Thread(() =>
            {
                try
                {
                    byte[] buffer = new byte[1024];
                    int length = 0;
                    while (true)
                    {
                        length = client.Receive(buffer);
                        if (length < 1) break;
                    }
                }
                finally
                {
                    On_Disconnected?.Invoke(this);
                }
            }).Start();
        }
    }
}
