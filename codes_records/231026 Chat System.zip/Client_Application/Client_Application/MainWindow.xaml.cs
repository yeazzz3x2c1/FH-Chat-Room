﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client_Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Server server;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += delegate { Initialize(); };
        }
        private void Initialize()
        {
            server = new Server();
            server.Server_Connected += delegate
            {
                status.Text = "連線成功";
            };
            server.Connection_Failed += delegate
            {
                status.Text = "連線失敗";
            };
            server.Connect();
        }
    }
}
