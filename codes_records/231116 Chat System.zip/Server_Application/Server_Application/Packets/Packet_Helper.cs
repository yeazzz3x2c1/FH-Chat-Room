﻿using Server_Application.Packets.Types;
using Server_Application.Packets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server_Application.Packets
{
    internal enum Packet_Type
    {
        Default = -1,
        Test = 0, // Hi this is test
        Hello = 1, // Hello!
    }
    internal class Packet_Helper
    {
        private static Type[] packet_types = new Type[]
        {
            typeof(Packet_Test),
            typeof(Packet_Hello),
        };
        public static Packet_Base Get_Packet_Instance(byte[] Raw_Data)
        {
            return (Packet_Base)Activator.CreateInstance(packet_types[Raw_Data[0]], Raw_Data);
        }
        public static byte[] Encode_Data(byte[] Raw_Data)
        {
            List<byte> raw_data = new List<byte>(Raw_Data);
            raw_data.Add(Calculate_CRC(Raw_Data));
            List<byte> bytes = new List<byte>();
            bytes.Add(2);
            bytes.AddRange(Encoding.ASCII.GetBytes(Convert.ToBase64String(raw_data.ToArray())));
            bytes.Add(3);
            return bytes.ToArray();
        }
        public static byte[] Decode_Data(byte[] Encoded_Data)
        {
            List<byte> bytes = new List<byte>(Encoded_Data);
            return Convert.FromBase64String(Encoding.ASCII.GetString(bytes.ToArray()));
        }
        public static byte Calculate_CRC(byte[] Data)
        {
            byte crc = 0;
            for (int i = 0; i < Data.Length; i++)
                crc += Data[i];
            return crc;
        }
        public static bool Check_CRC_Pass(byte[] Data)
        {
            byte crc = 0;
            for (int i = 0; i < Data.Length - 1; i++)
                crc += Data[i];
            return crc == Data[Data.Length - 1];
        }
    }
}
