﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client_Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Server server;
        public MainWindow()
        {
            InitializeComponent();
            status_container.Visibility = Visibility.Visible;
            Loaded += delegate { Initialize(); };
            Closing += delegate { Environment.Exit(0); };
        }
        private void Initialize()
        {

        }

        private void On_Connect_Click(object sender, RoutedEventArgs e)
        {
            server = new Server();
            server.Server_Connected += delegate
            {
                status_container.Visibility = Visibility.Hidden;
                server.Register_User(username.Text);
            };
            server.Connection_Failed += delegate
            {
                status.Text = "連線失敗";
                status_container.Visibility = Visibility.Visible;
            };
            server.Connect();
        }
    }
}
