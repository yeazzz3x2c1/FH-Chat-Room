﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server_Application
{
    internal class Client
    {
        Socket client;
        public Client(Socket client) {
            this.client = client;
            IPEndPoint ipendpoint = client.RemoteEndPoint as IPEndPoint;
            Console.WriteLine("收到了連線請求，IP:" + ipendpoint.Address + ":" + ipendpoint.Port);
            Listen();
        }
        private void Listen()
        {
            new Thread(() =>
            {
                byte[] buffer = new byte[1024];
                int length = 0;
                while (true)
                {
                    length = client.Receive(buffer);
                }
            }).Start();
        }
    }
}
