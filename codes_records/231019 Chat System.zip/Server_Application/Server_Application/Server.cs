﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server_Application
{
    internal class Server
    {
        int Port = 25565;
        Socket server;
        public Server() { }
        public void Build_Up()
        {
            new Thread(() =>
            {
                Console.WriteLine("正在啟動伺服器，埠號: " + Port);
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                server.Bind(new IPEndPoint(IPAddress.Any, Port));
                server.Listen(10);
                Console.WriteLine("伺服器啟動成功");
                while (true)
                {
                    try
                    {
                        new Client(server.Accept());
                    }catch (Exception ex)
                    {
                        break;
                    }
                }
            }).Start();
        }
        public void ShutDown()
        {
            try
            {
                server.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
