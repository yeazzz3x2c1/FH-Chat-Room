﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Client_Application
{
    internal class Server
    {
        public delegate void ServerConnectionHandler();
        public event ServerConnectionHandler Server_Connected;
        public event ServerConnectionHandler Connection_Failed;

        Socket server;
        public void Connect()
        {
            new Thread(() =>
            {
                //連線
                try
                {
                    Server_Connected?.Invoke();

                }catch (Exception ex)
                {
                    Connection_Failed?.Invoke();
                }
            }).Start();
        }
    }
}
