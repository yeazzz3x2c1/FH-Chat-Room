﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server_Application.Packets
{
    internal class Packet_Base
    {
        public Packet_Base() { }
        public virtual void Handle() { }
    }
}
