﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Application
{
    internal class Packet_Base
    {
        public Packet_Base() { }
        public virtual void Handle() { }
    }
}
