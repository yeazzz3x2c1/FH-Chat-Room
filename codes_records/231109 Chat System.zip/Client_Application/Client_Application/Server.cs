﻿using Client_Application.Packets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Client_Application
{
    internal class Server
    {
        public delegate void ServerConnectionHandler();
        public event ServerConnectionHandler Server_Connected;
        public event ServerConnectionHandler Connection_Failed;

        Socket server;
        TaskScheduler scheduler;
        public Server()
        {
            scheduler = TaskScheduler.FromCurrentSynchronizationContext();
        }

        public void Connect()
        {
            new Thread(() =>
            {
                //連線
                try
                {
                    server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    server.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 25565));

                    byte[] send_data = Packet_Helper.Encode_Data(new byte[] { (byte)Packet_Type.Test});
                    server.Send(send_data);
                    new Task(() => { Server_Connected?.Invoke(); }).Start(scheduler);
                }
                catch (Exception ex)
                {
                    new Task(() => { Connection_Failed?.Invoke(); }).Start(scheduler);
                }
            }).Start();
        }
    }
}
